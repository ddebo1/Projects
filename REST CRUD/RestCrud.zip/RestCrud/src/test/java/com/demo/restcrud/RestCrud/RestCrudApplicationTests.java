package com.demo.restcrud.RestCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
