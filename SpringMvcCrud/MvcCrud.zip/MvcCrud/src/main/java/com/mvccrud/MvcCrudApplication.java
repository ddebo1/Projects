package com.mvccrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcCrudApplication.class, args);
	}

}
